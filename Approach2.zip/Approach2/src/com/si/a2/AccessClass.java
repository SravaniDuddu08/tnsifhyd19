package com.si.a2;
class NormalClass{
	String singer="spb";
	static String dancer="prabhudeva";
	void display() {
		System.out.println("grate singer");
	}
	static String display1() {
		return "grate dancer";
	}
}
public class AccessClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NormalClass n1=new NormalClass();
		System.out.println(n1.singer);
		n1.display();
		System.out.println(NormalClass.dancer);
		System.out.println(NormalClass.display1());

	}

}
