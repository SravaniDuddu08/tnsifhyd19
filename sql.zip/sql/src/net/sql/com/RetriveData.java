package net.sql.com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RetriveData {
	
	public static void main(String[] args) {
		String dbURL = "jdbc:mysql://localhost:3306/employeedb";
		String username = "root";
		String password = "root";
		 
		try(Connection conn = DriverManager.getConnection(dbURL, username, password)) {
		 
			String sql = "SELECT * FROM employee";
			 
			Statement statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			 
			int count = 0;
			 
			while (result.next()){
			    String emp_id = result.getString(2);
			    
			    String name = result.getString("name");
			    String address = result.getString("address");
			 
			    String output = "User #%d: %s - %s - %s ";
			    System.out.println(String.format(output, ++count, emp_id,name,address));
			}
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}

	}

}
