/**
 * 
 */
/**
 * 
 */
module StaticVariables {
}