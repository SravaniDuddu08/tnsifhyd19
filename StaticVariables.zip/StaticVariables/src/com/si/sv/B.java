
package com.si.sv;

public class B {
    static int b=60;
    static void display1() {
    System.out.println("I am SRAVANI"); 
    }

	public static void main(String[] args) {
		System.out.println(B.b);
		
		
		// TODO Auto-generated method stub

	}

}
