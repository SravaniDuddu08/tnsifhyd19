package com.si.ap;

public class Teachers {
	int id=2;
	static String name="siri";
public static void main(String[] args) {
	int age=35;
	Teachers t1=new Teachers();
	System.out.println(t1.id);
	System.out.println(name);
	System.out.println(age);

	}

}
