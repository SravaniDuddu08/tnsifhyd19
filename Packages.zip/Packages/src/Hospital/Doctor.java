package Hospital;

public class Doctor {
	String name() {
		return "surya";
		
	}
    int age() {
    	return 35;
    }
    String department() {
    	return "cardiologist";
    }
	
}
  
