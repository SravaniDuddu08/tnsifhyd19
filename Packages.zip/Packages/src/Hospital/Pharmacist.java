package Hospital;

public class Pharmacist {
	 String name() {
		   return "Abhi";
	   }
	   int age() {
		   return 25;
	   }
	   int id() {
		   return 15;
	   }
 }
