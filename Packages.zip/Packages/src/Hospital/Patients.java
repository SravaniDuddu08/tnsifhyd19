package Hospital;

public class Patients {
	String name() {
		  return "Anil";
	  }
	  int age() {
		  return 40;
	  }
	  String disease() {
		  return "diabetes";
	  }
	  
}

