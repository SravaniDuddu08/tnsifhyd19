package Hospital;
import Hospital.*;

public class Main1 {



		  public static void main(String[]args) {
			
		
			   Doctor d1=new Doctor();
			   Patients p1=new Patients();
			   Pharmacist p2=new Pharmacist();
			   
			     
			   System.out.println(d1.name());	
			   System.out.println(d1.age());
			   System.out.println(d1.department());
			    
			   System.out.println(p1.name());
			   System.out.println(p1.age());
			   System.out.println(p1.disease());
			   System.out.println(p2.name());
			   System.out.println(p2.age());
			   System.out.println(p2.id());
			   
			   
			// TODO Auto-generated method stub

		}
	}



