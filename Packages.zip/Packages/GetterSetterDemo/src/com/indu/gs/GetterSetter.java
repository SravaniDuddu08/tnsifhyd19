package com.indu.gs;

public class GetterSetter {
private int a=67;
private String b="siri";
public int c=78;
public int getA() {
	return a;
}
public void setA(int a) {
	this.a = a;
}
public String getB() {
	return b;
}
public void setB(String b) {
	this.b = b;
}
public int getC() {
	return c;
}
public void setC(int c) {
	this.c = c;
}
}
