package com.si.iv;

public class A {
	int a=5;
	int display() {
		return a;
	}

	public static void main(String[] args) {
		A a1=new A();
		System.out.println(a1.a);
		System.out.println(a1.display());
		// TODO Auto-generated method stub

	}

}
