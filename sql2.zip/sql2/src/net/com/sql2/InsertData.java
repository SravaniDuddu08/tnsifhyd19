package net.com.sql2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertData {
	public static void main(String[] args) {
		String dbURL = "jdbc:mysql://localhost:3306/doctordb";
		String username = "root";
		String password = "root";
		 
		try {
		 
		    Connection conn = DriverManager.getConnection(dbURL, username, password);
		    String sql = "INSERT INTO doctor (name, age, department, experience, phnno) VALUES (?, ?, ?, ?, ?)";
		    
		    PreparedStatement statement = conn.prepareStatement(sql);
		    
		    statement.setString(1, "surya");
		    statement.setString(2, "35");
		    statement.setString(3, "Dermatologist");
		    statement.setString(4, "5");
		    statement.setString(5, "342");
		     
		    statement.setString(1, "sumitra");
		    statement.setString(2, "40");
		    statement.setString(3, "cardiologist");
		    statement.setString(4, "7");
		    statement.setString(5, "789");
		    
		    statement.setString(1, "Ashish");
		    statement.setString(2, "41");
		    statement.setString(3, "oncologist");
		    statement.setString(4, "6");
		    statement.setString(5, "894");
		     
		    statement.setString(1, "varnika");
		    statement.setString(2, "29");
		    statement.setString(3, "Neurologist");
		    statement.setString(4, "3");
		    statement.setString(5, "543");
		     
		    statement.setString(1, "Yug");
		    statement.setString(2, "28");
		    statement.setString(3, "psychiatrists");
		    statement.setString(4, "1");
		    statement.setString(5, "125");
		      
		     
		    int rowsInserted = statement.executeUpdate();
		    if (rowsInserted > 0) {
		        System.out.println("A new user was inserted successfully!");
		    }
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}
	}
	/*
	 * Using a Statement for a static SQL query. Using a PreparedStatement for a
	 * parameterized SQL query and using setXXX() methods to set values for the
	 * parameters. Using execute() method to execute general query. Using
	 * executeUpdate() method to execute INSERT, UPDATE or DELETE query Using
	 * executeQuery() method to execute SELECT query. Using a ResultSet to iterate
	 * over rows returned from a SELECT query, using its next() method to advance to
	 * next row in the result set, and using getXXX() methods to retrieve values of
	 * columns.
	 */	

}
