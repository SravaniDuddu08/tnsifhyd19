package net.com.sql2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RetriveData {
	
	public static void main(String[] args) {
		String dbURL = "jdbc:mysql://localhost:3306/doctordb";
		String username = "root";
		String password = "root";
		 
		try(Connection conn = DriverManager.getConnection(dbURL, username, password)) {
		 
			String sql = "SELECT * FROM doctor";
			 
			Statement statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			 
			int count = 0;
			 
			while (result.next()){
			    String name = result.getString("name");
			    String age = result.getString("age");
			    String department = result.getString("department");
			    String experience = result.getString("experience");
			    String phnno = result.getString("phnno");
			 
			    String output = "doctor #%d: %s - %s - %s - %s - %s";
			    System.out.println(String.format(output, ++count, name, age, department, experience, phnno));
			}
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}

	}

}
