/**
 * 
 */
/**
 * 
 */
module sql2 {
	requires java.sql;
}