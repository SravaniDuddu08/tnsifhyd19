package com.indu.si;
class A{
	int display() {
		return 6;
	}
	
}
class B extends A{
	int display() {
		return 7;
		}
	
	}
public class OverridingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B b1=new B();
		System.out.println(b1.display());
		
		

	}

}
