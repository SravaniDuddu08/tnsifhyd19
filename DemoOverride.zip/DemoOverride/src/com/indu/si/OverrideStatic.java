package com.indu.si;
class C{
	static void Base() {
		System.out.println("class C content");
	}

}
class D extends C{
	static void Base() {
		System.out.println("class A content");
	}
	
}
public class OverrideStatic{
	public static void main(String[] args) {
		C c1=new D();
		
		c1.Base();
	}
	}