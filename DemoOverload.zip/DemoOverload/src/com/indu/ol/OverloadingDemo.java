package com.indu.ol;
class One{
int display() {
	return 56;
}
}
class Two extends One{
  int display(int a) {
	return 6;
}
}
public class OverloadingDemo {

	public static void main(String[] args) {
	
		// TODO Auto-generated method stub
		Two t1=new Two();
		System.out.println(t1.display());
		System.out.println(t1.display(2));

	}

}

