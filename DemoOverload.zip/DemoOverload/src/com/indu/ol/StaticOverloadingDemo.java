package com.indu.ol;
class A{
	static int display() {
		return 50;
	}
}
class B extends A{
	static int display( int b) {
		return 60;
	}
}
public class StaticOverloadingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(B.display());
		System.out.println(B.display(5));
		
	}

}
